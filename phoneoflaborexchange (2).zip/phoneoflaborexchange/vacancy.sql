-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.5.62 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица phoneoflaborexchange.vacancy
CREATE TABLE IF NOT EXISTS `vacancy` (
  `IdV` bigint(255) unsigned NOT NULL AUTO_INCREMENT,
  `NameVacancy` varchar(50) NOT NULL,
  PRIMARY KEY (`IdV`),
  UNIQUE KEY `unique_Id` (`IdV`),
  UNIQUE KEY `unique_NameVacancy` (`NameVacancy`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы phoneoflaborexchange.vacancy: ~46 rows (приблизительно)
/*!40000 ALTER TABLE `vacancy` DISABLE KEYS */;
REPLACE INTO `vacancy` (`IdV`, `NameVacancy`) VALUES
	(2, 'Армировщик'),
	(17, 'Бухгалтер'),
	(41, 'Водитель'),
	(7, 'Воспитатель'),
	(9, 'Дворник'),
	(15, 'Делопроизводитель'),
	(42, 'Инженер ПТО'),
	(47, 'Инженер-геодезист'),
	(23, 'Инженер-технолог пищевого производства'),
	(24, 'Инженер-химик'),
	(3, 'Каменщик'),
	(26, 'Кухонный рабочий'),
	(21, 'Машинист'),
	(27, 'Машинист крана'),
	(8, 'Медицинская сестра'),
	(39, 'Менеджер отдела кадров'),
	(40, 'Менеджер по продажам'),
	(33, 'Механик'),
	(10, 'Младший воспитатель'),
	(1, 'Монолитчик'),
	(34, 'Оператор станков с программным управлением'),
	(32, 'Охранник'),
	(31, 'Педагог-психолог'),
	(19, 'Повар'),
	(37, 'Продавец-кассир'),
	(36, 'Продавец-консультант'),
	(45, 'Разнорабочий'),
	(28, 'Санитарка'),
	(4, 'Сварщик'),
	(16, 'Секретарь'),
	(22, 'Слесарь подвижного состава'),
	(38, 'Слесарь-наладчик'),
	(6, 'Сортировщик изделий'),
	(35, 'Старший специалист по закупкам'),
	(13, 'Товаровед'),
	(11, 'Токарь'),
	(46, 'Тракторист'),
	(29, 'Учитель информатики'),
	(30, 'Учитель технологии'),
	(18, 'Фармацевт'),
	(48, 'Швея'),
	(14, 'Шлифовщик'),
	(5, 'Штукатур-маляр'),
	(12, 'Экономист-аналитик отдела бюджетирования'),
	(20, 'Электромонтер'),
	(25, 'Юрист');
/*!40000 ALTER TABLE `vacancy` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
