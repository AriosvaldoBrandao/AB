-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.5.62 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица phoneoflaborexchange.employers
CREATE TABLE IF NOT EXISTS `employers` (
  `IdE` bigint(255) unsigned NOT NULL AUTO_INCREMENT,
  `NameEmployer` varchar(50) NOT NULL,
  `IdT` bigint(255) unsigned NOT NULL,
  `Adress` varchar(100) NOT NULL,
  `Director` varchar(30) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `BeginTime` time NOT NULL,
  `EndTime` time NOT NULL,
  PRIMARY KEY (`IdE`),
  UNIQUE KEY `unique_Id` (`IdE`),
  KEY `FK_employers_towns` (`IdT`),
  CONSTRAINT `FK_employers_towns` FOREIGN KEY (`IdT`) REFERENCES `towns` (`IdT`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы phoneoflaborexchange.employers: ~12 rows (приблизительно)
/*!40000 ALTER TABLE `employers` DISABLE KEYS */;
REPLACE INTO `employers` (`IdE`, `NameEmployer`, `IdT`, `Adress`, `Director`, `Phone`, `BeginTime`, `EndTime`) VALUES
	(2, 'АО Аромат', 27, 'ул. Производственная, д. 75', 'Васильев', '2421203', '09:00:00', '17:00:00'),
	(3, 'АО Казанский завод компрессорного машиностроения', 61, 'ул. Халитова, д. 1', 'Молчанов', '2917828', '08:00:00', '18:00:00'),
	(4, 'МУП Детский сад № 381', 36, 'ул. Мира, д. 12', 'Федорова', '1253300', '10:00:00', '14:00:00'),
	(5, 'ООО Спектр', 1, 'ул. Смольная, д. 15, подв. №0, ком. 22', 'Хорин', '5454181', '10:00:00', '16:00:00'),
	(6, 'ООО Арсенал-ММГ', 67, 'Московское шоссе, д. 92', 'Феоктистов', '2341210', '08:00:00', '17:00:00'),
	(7, 'ООО Арсенал', 1, 'ул. Бакунинская, д. 16', 'Прошин', '7542230', '10:00:00', '17:00:00'),
	(8, 'ООО Премиум Сервис', 1, 'ул. Касимовская, д. 39', 'Молчанов', '4235560', '10:00:00', '14:00:00'),
	(9, 'ООО Стройинвесттрубопровод', 47, 'ул. Промышленная, д. 10 оф. 107', 'Агеев', '3065279', '08:00:00', '16:00:00'),
	(10, 'Антал Бизнес Решения', 1, 'пер. Трёхпрудный, д. 9, стр. 1, оф. 104', 'Телятников', '9358606', '10:00:00', '18:00:00'),
	(11, 'ООО Универсальная строительная компания №1', 1, 'ул. Малахитовая, д. 27Б, оф. 103', 'Ишков', '6603979', '08:00:00', '15:00:00'),
	(12, 'ООО БелГруз', 9, 'ул. Губкина, д. 39', 'Афанасьев', '375265', '09:00:00', '17:00:00'),
	(13, 'ООО Феникс', 32, 'ул. Союзная, д. 5а', 'Иванов', '3421255', '09:00:00', '12:00:00');
/*!40000 ALTER TABLE `employers` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
