-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.5.62 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица phoneoflaborexchange.listvacancy
CREATE TABLE IF NOT EXISTS `listvacancy` (
  `Id` bigint(255) unsigned NOT NULL AUTO_INCREMENT,
  `IdV` bigint(255) unsigned NOT NULL,
  `IdE` bigint(255) unsigned NOT NULL,
  `StartSalary` decimal(10,2) unsigned NOT NULL DEFAULT '25000.00',
  `Status` int(255) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `index_IdV` (`IdV`),
  KEY `index_IdE` (`IdE`),
  CONSTRAINT `lnk_employers_listvacancy` FOREIGN KEY (`IdE`) REFERENCES `employers` (`IdE`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `lnk_vacancy_listvacancy` FOREIGN KEY (`IdV`) REFERENCES `vacancy` (`IdV`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы phoneoflaborexchange.listvacancy: ~23 rows (приблизительно)
/*!40000 ALTER TABLE `listvacancy` DISABLE KEYS */;
REPLACE INTO `listvacancy` (`Id`, `IdV`, `IdE`, `StartSalary`, `Status`) VALUES
	(1, 15, 3, 23000.00, 0),
	(2, 21, 9, 48000.00, 1),
	(3, 26, 7, 26000.00, 0),
	(4, 34, 3, 43000.00, 0),
	(5, 1, 6, 53000.00, 0),
	(6, 27, 6, 80000.00, 0),
	(7, 10, 4, 9500.00, 0),
	(8, 7, 4, 12500.00, 0),
	(9, 3, 6, 49000.00, 0),
	(11, 19, 7, 45000.00, 0),
	(12, 25, 10, 65000.00, 0),
	(13, 38, 3, 47000.00, 0),
	(14, 23, 5, 68000.00, 0),
	(15, 25, 2, 53000.00, 0),
	(16, 41, 11, 62000.00, 0),
	(17, 2, 6, 53000.00, 0),
	(18, 2, 11, 80000.00, 0),
	(19, 47, 11, 102000.00, 0),
	(20, 5, 6, 38000.00, 0),
	(21, 17, 8, 75000.00, 0),
	(22, 5, 11, 60000.00, 0),
	(23, 17, 9, 65000.00, 0),
	(24, 17, 2, 45000.00, 0);
/*!40000 ALTER TABLE `listvacancy` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
