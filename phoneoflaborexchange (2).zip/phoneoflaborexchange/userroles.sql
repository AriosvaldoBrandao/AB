-- --------------------------------------------------------
-- Хост:                         127.0.0.1
-- Версия сервера:               5.5.62 - MySQL Community Server (GPL)
-- Операционная система:         Win64
-- HeidiSQL Версия:              11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Дамп структуры для таблица phoneoflaborexchange.userroles
CREATE TABLE IF NOT EXISTS `userroles` (
  `IdU` bigint(255) unsigned NOT NULL AUTO_INCREMENT,
  `Login` varchar(25) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `IdR` bigint(255) NOT NULL,
  `IdE` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`IdU`),
  UNIQUE KEY `unique_IdU` (`IdU`),
  KEY `index_IdR` (`IdR`),
  CONSTRAINT `lnk_roles_userroles` FOREIGN KEY (`IdR`) REFERENCES `roles` (`IdR`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Дамп данных таблицы phoneoflaborexchange.userroles: ~4 rows (приблизительно)
/*!40000 ALTER TABLE `userroles` DISABLE KEYS */;
REPLACE INTO `userroles` (`IdU`, `Login`, `Password`, `IdR`, `IdE`) VALUES
	(1, 'admin', 'admin', 0, NULL),
	(2, 'ichar', '12345', 1, NULL),
	(3, 'arsenal_mmg', '090909', 2, 6),
	(4, 'test', 'test', 3, NULL);
/*!40000 ALTER TABLE `userroles` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
