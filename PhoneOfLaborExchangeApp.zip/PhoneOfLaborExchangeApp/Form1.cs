﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace PhoneOfLaborExchangeApp
{
    public partial class Form1 : Form
    {        
        public string IdE = "";
        public int EditOn = 0;
        public int UserMode = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void Cancelbtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            EmployerAddFormShowbtn.Visible = false;
            VacancyAddFormShowbtn.Visible = false;
            AddTownFormShowbtn.Visible = false;
            AddVacancyNameFormShowbtn.Visible = false;
            AddUserFormShowbtn.Visible = false;
            VacancyOfEmpShowbtn.Visible = false;
            // Создаем и открываем соединение с MySQL
            string @strConn = "";
            using (StreamReader sr = new StreamReader("BDConnect.ini"))
            {
                while (sr.Peek() >= 0)
                {
                    strConn = @sr.ReadLine();
                }
            }
            MySqlConnection conn = new MySqlConnection(@strConn);
            try
            {
                conn.Open();
                MySqlDataAdapter SDA = new MySqlDataAdapter("SELECT * FROM phoneoflaborexchange.listvacancyview", conn);
                DataTable DATA = new DataTable();
                SDA.Fill(DATA);
                MySqlDataAdapter townsDA = new MySqlDataAdapter("SELECT * FROM phoneoflaborexchange.townsview", conn);
                DataTable townsDATA = new DataTable();
                townsDA.Fill(townsDATA);
                dataGridView1.DataSource = DATA;
                dataGridView1.Columns[0].HeaderText = "Вакансия";
                dataGridView1.Columns[1].HeaderText = "Город";
                dataGridView1.Columns[2].HeaderText = "Организация";
                dataGridView1.Columns[3].HeaderText = "Стартовый оклад";
                dataGridView1.Columns[4].HeaderText = "Телефон";
                dataGridView1.Columns[5].HeaderText = "Адрес";
                dataGridView1.Columns[6].HeaderText = "Время собеседования";
                Townscombo.DataSource = townsDATA;
                Townscombo.DisplayMember = "NameTown";
                Townscombo.SelectedIndex = -1;
                //MessageBox.Show(Townscombo.SelectedText);
                MySqlCommand cmnd = new MySqlCommand("CountActiveVacancy", conn);
                cmnd.CommandType = CommandType.StoredProcedure;
                MySqlParameter prm = new MySqlParameter();
                prm.ParameterName = "@cntV";
                prm.MySqlDbType = MySqlDbType.Int32;
                prm.Size = 20;
                prm.Direction = ParameterDirection.Output;
                cmnd.Parameters.Add(prm);
                //cmnd.Parameters.AddWithValue("cntV", 1);
                //cmnd.Parameters. = ParameterDirection.Output;
                var result = cmnd.ExecuteNonQuery();
                ActiveVacancylbl.Text = cmnd.Parameters["@cntV"].Value.ToString();
                conn.Close();
                EditOn = 0;
                Form ModeForm = new ModeForm();
                ModeForm.Owner = this;
                ModeForm.ShowDialog();
                if (UserMode == -1)
                    Close();
                switch (UserMode)
                {
                    case -1:
                        Close();
                        break;
                    case 0:
                        //Вход в систему как администратор
                        EmployerAddFormShowbtn.Visible = true;
                        VacancyAddFormShowbtn.Visible = true;
                        AddTownFormShowbtn.Visible = true;
                        AddVacancyNameFormShowbtn.Visible = true;
                        AddUserFormShowbtn.Visible = true;
                        break;
                    case 1:
                        //Вход в систему как сотрудник биржи
                        EmployerAddFormShowbtn.Visible = true;
                        VacancyAddFormShowbtn.Visible = true;
                        break;
                    case 2:
                        //Вход в систему как работодатель
                        VacancytextBox.Visible = false;
                        Townscombo.Visible = false; 
                        BeginSalarytextBox.Visible = false; 
                        EndSalarytextBox.Visible = false;
                        label2.Visible = false;
                        label3.Visible = false;
                        label5.Visible = false;
                        label6.Visible = false;
                        ActiveVacancyRunbtn.Visible= false;
                        FindVacancybtn.Visible = false;
                        Clearbtn.Visible = false;
                        VacancyOfEmpShowbtn_Click(sender, e);
                        break;
                    case 3:
                        //Вход в систему как соискатель
                        break;
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void Runbtn_Click(object sender, EventArgs e)
        {
        }

        private void ActiveVacancyRunbtn_Click(object sender, EventArgs e)
        {
            // Создаем и открываем соединение с MySQL
            string @strConn = "";
            using (StreamReader sr = new StreamReader("BDConnect.ini"))
            {
                while (sr.Peek() >= 0)
                {
                    strConn = @sr.ReadLine();
                }
            }
            MySqlConnection conn = new MySqlConnection(@strConn);
            try
            {
                conn.Open();
                MySqlCommand cmnd0 = new MySqlCommand("ActiveVacancy", conn);
                cmnd0.CommandType = CommandType.StoredProcedure;
                var aVac = cmnd0.ExecuteReader();
                //MySqlDataAdapter SDA = new MySqlDataAdapter("SELECT * FROM phoneoflaborexchange.listvacancyview", conn);
                DataTable DATA = new DataTable();
                DATA.Load(aVac);
                //SDA.Fill(DATA);
                MySqlDataAdapter townsDA = new MySqlDataAdapter("SELECT * FROM phoneoflaborexchange.townsview", conn);
                DataTable townsDATA = new DataTable();
                townsDA.Fill(townsDATA);
                dataGridView1.DataSource = DATA;
                dataGridView1.Columns[0].HeaderText = "Вакансия";
                dataGridView1.Columns[1].HeaderText = "Город";
                dataGridView1.Columns[2].HeaderText = "Организация";
                dataGridView1.Columns[3].HeaderText = "Стартовый оклад";
                dataGridView1.Columns[4].HeaderText = "Телефон";
                dataGridView1.Columns[5].HeaderText = "Адрес";
                dataGridView1.Columns[6].HeaderText = "Время собеседования";
                MySqlCommand cmnd = new MySqlCommand("CountActiveVacancy", conn);
                cmnd.CommandType = CommandType.StoredProcedure;
                MySqlParameter prm = new MySqlParameter();
                prm.ParameterName = "@cntV";
                prm.MySqlDbType = MySqlDbType.Int32;
                prm.Size = 20;
                prm.Direction = ParameterDirection.Output;
                cmnd.Parameters.Add(prm);
                var result = cmnd.ExecuteNonQuery();
                ActiveVacancylbl.Text = cmnd.Parameters["@cntV"].Value.ToString();
                conn.Close();
              }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void EmployerAddFormShowbtn_Click(object sender, EventArgs e)
        {
            EditOn = 1;
            Form EmploersForm = new EmploersForm();
            EmploersForm.Owner = this;
            EmploersForm.ShowDialog();
        }

        private void VacancyAddFormShowbtn_Click(object sender, EventArgs e)
        {
            EditOn = 2;
            Form EmploersForm = new EmploersForm();
            EmploersForm.Owner = this;
            EmploersForm.ShowDialog();
        }

        private void VacancyOfEmpShowbtn_Click(object sender, EventArgs e)
        {
            // Создаем и открываем соединение с MySQL
            string @strConn = "";
            using (StreamReader sr = new StreamReader("BDConnect.ini"))
            {
                while (sr.Peek() >= 0)
                {
                    strConn = @sr.ReadLine();
                }
            }
            MySqlConnection conn = new MySqlConnection(@strConn);
            try
            {
                conn.Open();
                string StrQuery = "SELECT NameVacancy,NameTown,NameEmployer,StartSalary,CONCAT('8(',PhoneCod,')',Phone) AS Phone,Adress,CONCAT(left(BeginTime,5),' - ',left(EndTime,5)) AS InterviewTime";
                StrQuery = StrQuery + " FROM listvacancy, vacancy, employers, towns";
                StrQuery = StrQuery + " WHERE listvacancy.IdV = vacancy.IdV AND listvacancy.IdE = employers.IdE AND employers.IdT = towns.IdT AND listvacancy.IdE=" + IdE;
                MessageBox.Show(StrQuery);
                MySqlDataAdapter SDA = new MySqlDataAdapter(StrQuery, conn);
                DataTable DATA = new DataTable();
                SDA.Fill(DATA);
                dataGridView1.DataSource = DATA;
                dataGridView1.Columns[0].HeaderText = "Вакансия";
                dataGridView1.Columns[1].HeaderText = "Город";
                dataGridView1.Columns[2].HeaderText = "Организация";
                dataGridView1.Columns[3].HeaderText = "Стартовый оклад";
                dataGridView1.Columns[4].HeaderText = "Телефон";
                dataGridView1.Columns[5].HeaderText = "Адрес";
                dataGridView1.Columns[6].HeaderText = "Время собеседования";
                conn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void AddUserFormShowbtn_Click(object sender, EventArgs e)
        {            
            Form UsersForm = new UsersForm();
            UsersForm.Owner = this;
            UsersForm.ShowDialog();
        }

        private void FindVacancybtn_Click(object sender, EventArgs e)
        {
            string StrQuery = "";
            if (VacancytextBox.Text != "" && Townscombo.SelectedIndex == -1 && BeginSalarytextBox.Text == "" && EndSalarytextBox.Text == "")
            {
                StrQuery = "SELECT * FROM listvacancyview WHERE UPPER(NameVacancy)='" + VacancytextBox.Text.ToUpper() + "'";
            }
            else
            {
                if (VacancytextBox.Text != "" && Townscombo.SelectedIndex != -1 && BeginSalarytextBox.Text == "" && EndSalarytextBox.Text == "")
                {
                    StrQuery = "SELECT NameVacancy,NameTown,NameEmployer,StartSalary,CONCAT('8(',PhoneCod,')',Phone) AS Phone,Adress,CONCAT(left(BeginTime,5),' - ',left(EndTime,5)) AS InterviewTime";
                    StrQuery = StrQuery + " FROM listvacancy, vacancy, employers, towns";
                    StrQuery = StrQuery + " WHERE listvacancy.IdV = vacancy.IdV AND listvacancy.IdE = employers.IdE AND employers.IdT = towns.IdT AND NameTown='" + Townscombo.Text+"'";
                    StrQuery = StrQuery + " AND UPPER(NameVacancy)='" + VacancytextBox.Text.ToUpper() + "'";
                }
                else
                {
                    if (VacancytextBox.Text != "" && Townscombo.SelectedIndex != -1 && BeginSalarytextBox.Text != "" && EndSalarytextBox.Text == "")
                    {
                        StrQuery = "SELECT NameVacancy,NameTown,NameEmployer,StartSalary,CONCAT('8(',PhoneCod,')',Phone) AS Phone,Adress,CONCAT(left(BeginTime,5),' - ',left(EndTime,5)) AS InterviewTime";
                        StrQuery = StrQuery + " FROM listvacancy, vacancy, employers, towns";
                        StrQuery = StrQuery + " WHERE listvacancy.IdV = vacancy.IdV AND listvacancy.IdE = employers.IdE AND employers.IdT = towns.IdT AND NameTown='" + Townscombo.Text + "'";
                        StrQuery = StrQuery + " AND UPPER(NameVacancy)='" + VacancytextBox.Text.ToUpper() + "'";
                        StrQuery = StrQuery + " AND StartSalary>=" + BeginSalarytextBox.Text;
                    }
                    else
                    {
                        if (VacancytextBox.Text != "" && Townscombo.SelectedIndex != -1 && BeginSalarytextBox.Text != "" && EndSalarytextBox.Text != "")
                        {
                            StrQuery = "SELECT NameVacancy,NameTown,NameEmployer,StartSalary,CONCAT('8(',PhoneCod,')',Phone) AS Phone,Adress,CONCAT(left(BeginTime,5),' - ',left(EndTime,5)) AS InterviewTime";
                            StrQuery = StrQuery + " FROM listvacancy, vacancy, employers, towns";
                            StrQuery = StrQuery + " WHERE listvacancy.IdV = vacancy.IdV AND listvacancy.IdE = employers.IdE AND employers.IdT = towns.IdT AND NameTown='" + Townscombo.Text + "'";
                            StrQuery = StrQuery + " AND UPPER(NameVacancy)='" + VacancytextBox.Text.ToUpper() + "'";
                            StrQuery = StrQuery + " AND StartSalary>=" + BeginSalarytextBox.Text;
                            StrQuery = StrQuery + " AND StartSalary<=" + EndSalarytextBox.Text;
                        }
                        else
                        {
                            if (VacancytextBox.Text != "" && Townscombo.SelectedIndex == -1 && BeginSalarytextBox.Text != "" && EndSalarytextBox.Text == "")
                            {
                                StrQuery = "SELECT NameVacancy,NameTown,NameEmployer,StartSalary,CONCAT('8(',PhoneCod,')',Phone) AS Phone,Adress,CONCAT(left(BeginTime,5),' - ',left(EndTime,5)) AS InterviewTime";
                                StrQuery = StrQuery + " FROM listvacancy, vacancy, employers, towns";
                                StrQuery = StrQuery + " WHERE listvacancy.IdV = vacancy.IdV AND listvacancy.IdE = employers.IdE AND employers.IdT = towns.IdT";
                                StrQuery = StrQuery + " AND UPPER(NameVacancy)='" + VacancytextBox.Text.ToUpper() + "'";
                                StrQuery = StrQuery + " AND StartSalary>=" + BeginSalarytextBox.Text;
                            }
                            else
                            {
                                if (VacancytextBox.Text != "" && Townscombo.SelectedIndex == -1 && BeginSalarytextBox.Text != "" && EndSalarytextBox.Text != "")
                                {
                                    StrQuery = "SELECT NameVacancy,NameTown,NameEmployer,StartSalary,CONCAT('8(',PhoneCod,')',Phone) AS Phone,Adress,CONCAT(left(BeginTime,5),' - ',left(EndTime,5)) AS InterviewTime";
                                    StrQuery = StrQuery + " FROM listvacancy, vacancy, employers, towns";
                                    StrQuery = StrQuery + " WHERE listvacancy.IdV = vacancy.IdV AND listvacancy.IdE = employers.IdE AND employers.IdT = towns.IdT";
                                    StrQuery = StrQuery + " AND UPPER(NameVacancy)='" + VacancytextBox.Text.ToUpper() + "'";
                                    StrQuery = StrQuery + " AND StartSalary>=" + BeginSalarytextBox.Text;
                                    StrQuery = StrQuery + " AND StartSalary<=" + EndSalarytextBox.Text;
                                }
                                else
                                {
                                    MessageBox.Show("Этот запрос не может быть осуществлен!");
                                    return;
                                }
                            }

                        }
                    }

                }
            }
            // Создаем и открываем соединение с MySQL
            string @strConn = "";
            using (StreamReader sr = new StreamReader("BDConnect.ini"))
            {
                while (sr.Peek() >= 0)
                {
                    strConn = @sr.ReadLine();
                }
            }
            MySqlConnection conn = new MySqlConnection(@strConn);
            try
            {
                conn.Open();               
                MessageBox.Show(StrQuery);
                MySqlDataAdapter SDA = new MySqlDataAdapter(StrQuery, conn);
                DataTable DATA = new DataTable();
                SDA.Fill(DATA);
                dataGridView1.DataSource = DATA;
                dataGridView1.Columns[0].HeaderText = "Вакансия";
                dataGridView1.Columns[1].HeaderText = "Город";
                dataGridView1.Columns[2].HeaderText = "Организация";
                dataGridView1.Columns[3].HeaderText = "Стартовый оклад";
                dataGridView1.Columns[4].HeaderText = "Телефон";
                dataGridView1.Columns[5].HeaderText = "Адрес";
                dataGridView1.Columns[6].HeaderText = "Время собеседования";
                conn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void Clearbtn_Click(object sender, EventArgs e)
        {
            ActiveVacancyRunbtn_Click(sender, e);
        }

        private void AddTownFormShowbtn_Click(object sender, EventArgs e)
        {
            EditOn = 3;
            Form EmploersForm = new EmploersForm();
            EmploersForm.Owner = this;
            EmploersForm.ShowDialog();
        }

        private void AddVacancyNameFormShowbtn_Click(object sender, EventArgs e)
        {
            EditOn = 4;
            Form EmploersForm = new EmploersForm();
            EmploersForm.Owner = this;
            EmploersForm.ShowDialog();
        }
    }
}
