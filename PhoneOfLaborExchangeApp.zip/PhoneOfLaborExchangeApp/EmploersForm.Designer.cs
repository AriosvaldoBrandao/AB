﻿
namespace PhoneOfLaborExchangeApp
{
    partial class EmploersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControlEmployers = new System.Windows.Forms.TabControl();
            this.tabPageEmployers = new System.Windows.Forms.TabPage();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxAdress = new System.Windows.Forms.TextBox();
            this.SaveEmployerbtn = new System.Windows.Forms.Button();
            this.DelEmployerbtn = new System.Windows.Forms.Button();
            this.EditEmployerbtn = new System.Windows.Forms.Button();
            this.AddEmployerbtn = new System.Windows.Forms.Button();
            this.textBoxPhone = new System.Windows.Forms.TextBox();
            this.Townscombo = new System.Windows.Forms.ComboBox();
            this.textBoxNameEmployer = new System.Windows.Forms.TextBox();
            this.textBoxDirector = new System.Windows.Forms.TextBox();
            this.maskedTextBoxEndTime = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBoxBeginTime = new System.Windows.Forms.MaskedTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridViewEmployers = new System.Windows.Forms.DataGridView();
            this.tabPageVacancy = new System.Windows.Forms.TabPage();
            this.StatuscomboBox = new System.Windows.Forms.ComboBox();
            this.SalarytextBox = new System.Windows.Forms.TextBox();
            this.EmployerscomboBox = new System.Windows.Forms.ComboBox();
            this.VacancycomboBox = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.SaveVacInListbtn = new System.Windows.Forms.Button();
            this.DelVacInListbtn = new System.Windows.Forms.Button();
            this.EditVacInListbtn = new System.Windows.Forms.Button();
            this.AddVacInListbtn = new System.Windows.Forms.Button();
            this.dataGridViewListVacancy = new System.Windows.Forms.DataGridView();
            this.tabPageTowns = new System.Windows.Forms.TabPage();
            this.SaveTownbtn = new System.Windows.Forms.Button();
            this.DelTownbtn = new System.Windows.Forms.Button();
            this.EditTownbtn = new System.Windows.Forms.Button();
            this.AddTownbtn = new System.Windows.Forms.Button();
            this.textBoxPhoneCode = new System.Windows.Forms.TextBox();
            this.textBoxNameTown = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.dataGridViewTowns = new System.Windows.Forms.DataGridView();
            this.tabPageNameVacancy = new System.Windows.Forms.TabPage();
            this.dataGridViewVacancy = new System.Windows.Forms.DataGridView();
            this.SaveVacancybtn = new System.Windows.Forms.Button();
            this.DelVacancybtn = new System.Windows.Forms.Button();
            this.EditVacancybtn = new System.Windows.Forms.Button();
            this.AddVacancybtn = new System.Windows.Forms.Button();
            this.textBoxNameVacancy = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.Closebtn = new System.Windows.Forms.Button();
            this.tabControlEmployers.SuspendLayout();
            this.tabPageEmployers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployers)).BeginInit();
            this.tabPageVacancy.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListVacancy)).BeginInit();
            this.tabPageTowns.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTowns)).BeginInit();
            this.tabPageNameVacancy.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacancy)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControlEmployers
            // 
            this.tabControlEmployers.Controls.Add(this.tabPageEmployers);
            this.tabControlEmployers.Controls.Add(this.tabPageVacancy);
            this.tabControlEmployers.Controls.Add(this.tabPageTowns);
            this.tabControlEmployers.Controls.Add(this.tabPageNameVacancy);
            this.tabControlEmployers.Location = new System.Drawing.Point(12, 41);
            this.tabControlEmployers.Name = "tabControlEmployers";
            this.tabControlEmployers.SelectedIndex = 0;
            this.tabControlEmployers.Size = new System.Drawing.Size(1083, 572);
            this.tabControlEmployers.TabIndex = 0;
            this.tabControlEmployers.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabControlEmployers_Selecting);
            // 
            // tabPageEmployers
            // 
            this.tabPageEmployers.Controls.Add(this.label10);
            this.tabPageEmployers.Controls.Add(this.textBoxAdress);
            this.tabPageEmployers.Controls.Add(this.SaveEmployerbtn);
            this.tabPageEmployers.Controls.Add(this.DelEmployerbtn);
            this.tabPageEmployers.Controls.Add(this.EditEmployerbtn);
            this.tabPageEmployers.Controls.Add(this.AddEmployerbtn);
            this.tabPageEmployers.Controls.Add(this.textBoxPhone);
            this.tabPageEmployers.Controls.Add(this.Townscombo);
            this.tabPageEmployers.Controls.Add(this.textBoxNameEmployer);
            this.tabPageEmployers.Controls.Add(this.textBoxDirector);
            this.tabPageEmployers.Controls.Add(this.maskedTextBoxEndTime);
            this.tabPageEmployers.Controls.Add(this.maskedTextBoxBeginTime);
            this.tabPageEmployers.Controls.Add(this.label7);
            this.tabPageEmployers.Controls.Add(this.label6);
            this.tabPageEmployers.Controls.Add(this.label5);
            this.tabPageEmployers.Controls.Add(this.label4);
            this.tabPageEmployers.Controls.Add(this.label3);
            this.tabPageEmployers.Controls.Add(this.label2);
            this.tabPageEmployers.Controls.Add(this.label1);
            this.tabPageEmployers.Controls.Add(this.dataGridViewEmployers);
            this.tabPageEmployers.Location = new System.Drawing.Point(4, 25);
            this.tabPageEmployers.Name = "tabPageEmployers";
            this.tabPageEmployers.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageEmployers.Size = new System.Drawing.Size(1075, 543);
            this.tabPageEmployers.TabIndex = 0;
            this.tabPageEmployers.Text = "Сведения о работодателе";
            this.tabPageEmployers.UseVisualStyleBackColor = true;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(461, 413);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(136, 17);
            this.label10.TabIndex = 20;
            this.label10.Text = "Адрес организации";
            // 
            // textBoxAdress
            // 
            this.textBoxAdress.Location = new System.Drawing.Point(464, 433);
            this.textBoxAdress.Name = "textBoxAdress";
            this.textBoxAdress.Size = new System.Drawing.Size(439, 22);
            this.textBoxAdress.TabIndex = 3;
            // 
            // SaveEmployerbtn
            // 
            this.SaveEmployerbtn.Location = new System.Drawing.Point(968, 499);
            this.SaveEmployerbtn.Name = "SaveEmployerbtn";
            this.SaveEmployerbtn.Size = new System.Drawing.Size(99, 31);
            this.SaveEmployerbtn.TabIndex = 11;
            this.SaveEmployerbtn.Text = "Сохранить";
            this.SaveEmployerbtn.UseVisualStyleBackColor = true;
            this.SaveEmployerbtn.Click += new System.EventHandler(this.SaveEmployerbtn_Click);
            // 
            // DelEmployerbtn
            // 
            this.DelEmployerbtn.Location = new System.Drawing.Point(874, 499);
            this.DelEmployerbtn.Name = "DelEmployerbtn";
            this.DelEmployerbtn.Size = new System.Drawing.Size(90, 31);
            this.DelEmployerbtn.TabIndex = 10;
            this.DelEmployerbtn.Text = "Удалить";
            this.DelEmployerbtn.UseVisualStyleBackColor = true;
            this.DelEmployerbtn.Click += new System.EventHandler(this.DelEmployerbtn_Click);
            // 
            // EditEmployerbtn
            // 
            this.EditEmployerbtn.Location = new System.Drawing.Point(761, 499);
            this.EditEmployerbtn.Name = "EditEmployerbtn";
            this.EditEmployerbtn.Size = new System.Drawing.Size(107, 31);
            this.EditEmployerbtn.TabIndex = 9;
            this.EditEmployerbtn.Text = "Изменить";
            this.EditEmployerbtn.UseVisualStyleBackColor = true;
            this.EditEmployerbtn.Click += new System.EventHandler(this.EditEmployerbtn_Click);
            // 
            // AddEmployerbtn
            // 
            this.AddEmployerbtn.Location = new System.Drawing.Point(659, 499);
            this.AddEmployerbtn.Name = "AddEmployerbtn";
            this.AddEmployerbtn.Size = new System.Drawing.Size(96, 31);
            this.AddEmployerbtn.TabIndex = 8;
            this.AddEmployerbtn.Text = "Добавить";
            this.AddEmployerbtn.UseVisualStyleBackColor = true;
            this.AddEmployerbtn.Click += new System.EventHandler(this.AddEmployerbtn_Click);
            // 
            // textBoxPhone
            // 
            this.textBoxPhone.Location = new System.Drawing.Point(6, 503);
            this.textBoxPhone.Name = "textBoxPhone";
            this.textBoxPhone.Size = new System.Drawing.Size(149, 22);
            this.textBoxPhone.TabIndex = 5;
            // 
            // Townscombo
            // 
            this.Townscombo.FormattingEnabled = true;
            this.Townscombo.Location = new System.Drawing.Point(6, 433);
            this.Townscombo.Name = "Townscombo";
            this.Townscombo.Size = new System.Drawing.Size(160, 24);
            this.Townscombo.TabIndex = 1;
            // 
            // textBoxNameEmployer
            // 
            this.textBoxNameEmployer.Location = new System.Drawing.Point(172, 433);
            this.textBoxNameEmployer.Name = "textBoxNameEmployer";
            this.textBoxNameEmployer.Size = new System.Drawing.Size(286, 22);
            this.textBoxNameEmployer.TabIndex = 2;
            // 
            // textBoxDirector
            // 
            this.textBoxDirector.Location = new System.Drawing.Point(909, 433);
            this.textBoxDirector.Name = "textBoxDirector";
            this.textBoxDirector.Size = new System.Drawing.Size(160, 22);
            this.textBoxDirector.TabIndex = 4;
            // 
            // maskedTextBoxEndTime
            // 
            this.maskedTextBoxEndTime.Location = new System.Drawing.Point(261, 503);
            this.maskedTextBoxEndTime.Mask = "00:00";
            this.maskedTextBoxEndTime.Name = "maskedTextBoxEndTime";
            this.maskedTextBoxEndTime.Size = new System.Drawing.Size(79, 22);
            this.maskedTextBoxEndTime.TabIndex = 7;
            this.maskedTextBoxEndTime.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBoxBeginTime
            // 
            this.maskedTextBoxBeginTime.Location = new System.Drawing.Point(172, 503);
            this.maskedTextBoxBeginTime.Mask = "00:00";
            this.maskedTextBoxBeginTime.Name = "maskedTextBoxBeginTime";
            this.maskedTextBoxBeginTime.Size = new System.Drawing.Size(83, 22);
            this.maskedTextBoxBeginTime.TabIndex = 6;
            this.maskedTextBoxBeginTime.ValidatingType = typeof(System.DateTime);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(169, 483);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(23, 17);
            this.label7.TabIndex = 7;
            this.label7.Text = "от";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(258, 483);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "до";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(169, 466);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(155, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Время собеседований";
            // 
            // label4
            // 
            this.label4.AutoEllipsis = true;
            this.label4.Location = new System.Drawing.Point(6, 466);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 40);
            this.label4.TabIndex = 4;
            this.label4.Text = "Номер телефона (без кода города)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(906, 413);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Директор";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(169, 413);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(160, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Название организации";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 413);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Город";
            // 
            // dataGridViewEmployers
            // 
            this.dataGridViewEmployers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEmployers.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewEmployers.Name = "dataGridViewEmployers";
            this.dataGridViewEmployers.ReadOnly = true;
            this.dataGridViewEmployers.RowHeadersWidth = 51;
            this.dataGridViewEmployers.RowTemplate.Height = 24;
            this.dataGridViewEmployers.Size = new System.Drawing.Size(1063, 374);
            this.dataGridViewEmployers.TabIndex = 0;
            this.dataGridViewEmployers.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewEmployers_CellClick);
            // 
            // tabPageVacancy
            // 
            this.tabPageVacancy.Controls.Add(this.StatuscomboBox);
            this.tabPageVacancy.Controls.Add(this.SalarytextBox);
            this.tabPageVacancy.Controls.Add(this.EmployerscomboBox);
            this.tabPageVacancy.Controls.Add(this.VacancycomboBox);
            this.tabPageVacancy.Controls.Add(this.label16);
            this.tabPageVacancy.Controls.Add(this.label15);
            this.tabPageVacancy.Controls.Add(this.label14);
            this.tabPageVacancy.Controls.Add(this.label12);
            this.tabPageVacancy.Controls.Add(this.SaveVacInListbtn);
            this.tabPageVacancy.Controls.Add(this.DelVacInListbtn);
            this.tabPageVacancy.Controls.Add(this.EditVacInListbtn);
            this.tabPageVacancy.Controls.Add(this.AddVacInListbtn);
            this.tabPageVacancy.Controls.Add(this.dataGridViewListVacancy);
            this.tabPageVacancy.Location = new System.Drawing.Point(4, 25);
            this.tabPageVacancy.Name = "tabPageVacancy";
            this.tabPageVacancy.Padding = new System.Windows.Forms.Padding(3);
            this.tabPageVacancy.Size = new System.Drawing.Size(1075, 543);
            this.tabPageVacancy.TabIndex = 1;
            this.tabPageVacancy.Text = "Сведения о вакансиях";
            this.tabPageVacancy.UseVisualStyleBackColor = true;
            // 
            // StatuscomboBox
            // 
            this.StatuscomboBox.FormattingEnabled = true;
            this.StatuscomboBox.Items.AddRange(new object[] {
            "Свободная",
            "Закрытая"});
            this.StatuscomboBox.Location = new System.Drawing.Point(819, 460);
            this.StatuscomboBox.Name = "StatuscomboBox";
            this.StatuscomboBox.Size = new System.Drawing.Size(152, 24);
            this.StatuscomboBox.TabIndex = 5;
            // 
            // SalarytextBox
            // 
            this.SalarytextBox.Location = new System.Drawing.Point(686, 460);
            this.SalarytextBox.Name = "SalarytextBox";
            this.SalarytextBox.Size = new System.Drawing.Size(127, 22);
            this.SalarytextBox.TabIndex = 4;
            // 
            // EmployerscomboBox
            // 
            this.EmployerscomboBox.FormattingEnabled = true;
            this.EmployerscomboBox.Location = new System.Drawing.Point(284, 460);
            this.EmployerscomboBox.Name = "EmployerscomboBox";
            this.EmployerscomboBox.Size = new System.Drawing.Size(396, 24);
            this.EmployerscomboBox.TabIndex = 3;
            // 
            // VacancycomboBox
            // 
            this.VacancycomboBox.FormattingEnabled = true;
            this.VacancycomboBox.Location = new System.Drawing.Point(6, 460);
            this.VacancycomboBox.Name = "VacancycomboBox";
            this.VacancycomboBox.Size = new System.Drawing.Size(272, 24);
            this.VacancycomboBox.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(816, 435);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 17);
            this.label16.TabIndex = 20;
            this.label16.Text = "Статус";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(683, 435);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(123, 17);
            this.label15.TabIndex = 19;
            this.label15.Text = "Стартовый оклад";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(281, 435);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(102, 17);
            this.label14.TabIndex = 18;
            this.label14.Text = "Работодатель";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 435);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 17);
            this.label12.TabIndex = 16;
            this.label12.Text = "Вакансия";
            // 
            // SaveVacInListbtn
            // 
            this.SaveVacInListbtn.Location = new System.Drawing.Point(317, 503);
            this.SaveVacInListbtn.Name = "SaveVacInListbtn";
            this.SaveVacInListbtn.Size = new System.Drawing.Size(99, 31);
            this.SaveVacInListbtn.TabIndex = 9;
            this.SaveVacInListbtn.Text = "Сохранить";
            this.SaveVacInListbtn.UseVisualStyleBackColor = true;
            this.SaveVacInListbtn.Click += new System.EventHandler(this.SaveVacInListbtn_Click);
            // 
            // DelVacInListbtn
            // 
            this.DelVacInListbtn.Location = new System.Drawing.Point(223, 503);
            this.DelVacInListbtn.Name = "DelVacInListbtn";
            this.DelVacInListbtn.Size = new System.Drawing.Size(90, 31);
            this.DelVacInListbtn.TabIndex = 8;
            this.DelVacInListbtn.Text = "Удалить";
            this.DelVacInListbtn.UseVisualStyleBackColor = true;
            this.DelVacInListbtn.Click += new System.EventHandler(this.DelVacInListbtn_Click);
            // 
            // EditVacInListbtn
            // 
            this.EditVacInListbtn.Location = new System.Drawing.Point(110, 503);
            this.EditVacInListbtn.Name = "EditVacInListbtn";
            this.EditVacInListbtn.Size = new System.Drawing.Size(107, 31);
            this.EditVacInListbtn.TabIndex = 7;
            this.EditVacInListbtn.Text = "Изменить";
            this.EditVacInListbtn.UseVisualStyleBackColor = true;
            this.EditVacInListbtn.Click += new System.EventHandler(this.EditVacInListbtn_Click_1);
            // 
            // AddVacInListbtn
            // 
            this.AddVacInListbtn.Location = new System.Drawing.Point(8, 503);
            this.AddVacInListbtn.Name = "AddVacInListbtn";
            this.AddVacInListbtn.Size = new System.Drawing.Size(96, 31);
            this.AddVacInListbtn.TabIndex = 6;
            this.AddVacInListbtn.Text = "Добавить";
            this.AddVacInListbtn.UseVisualStyleBackColor = true;
            this.AddVacInListbtn.Click += new System.EventHandler(this.AddVacInListbtn_Click);
            // 
            // dataGridViewListVacancy
            // 
            this.dataGridViewListVacancy.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewListVacancy.Location = new System.Drawing.Point(6, 6);
            this.dataGridViewListVacancy.Name = "dataGridViewListVacancy";
            this.dataGridViewListVacancy.ReadOnly = true;
            this.dataGridViewListVacancy.RowHeadersWidth = 51;
            this.dataGridViewListVacancy.RowTemplate.Height = 24;
            this.dataGridViewListVacancy.Size = new System.Drawing.Size(1063, 412);
            this.dataGridViewListVacancy.TabIndex = 0;
            this.dataGridViewListVacancy.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewListVacancy_CellClick);
            // 
            // tabPageTowns
            // 
            this.tabPageTowns.Controls.Add(this.SaveTownbtn);
            this.tabPageTowns.Controls.Add(this.DelTownbtn);
            this.tabPageTowns.Controls.Add(this.EditTownbtn);
            this.tabPageTowns.Controls.Add(this.AddTownbtn);
            this.tabPageTowns.Controls.Add(this.textBoxPhoneCode);
            this.tabPageTowns.Controls.Add(this.textBoxNameTown);
            this.tabPageTowns.Controls.Add(this.label9);
            this.tabPageTowns.Controls.Add(this.label8);
            this.tabPageTowns.Controls.Add(this.dataGridViewTowns);
            this.tabPageTowns.Location = new System.Drawing.Point(4, 25);
            this.tabPageTowns.Name = "tabPageTowns";
            this.tabPageTowns.Size = new System.Drawing.Size(1075, 543);
            this.tabPageTowns.TabIndex = 2;
            this.tabPageTowns.Text = "Города";
            this.tabPageTowns.UseVisualStyleBackColor = true;
            // 
            // SaveTownbtn
            // 
            this.SaveTownbtn.Location = new System.Drawing.Point(919, 92);
            this.SaveTownbtn.Name = "SaveTownbtn";
            this.SaveTownbtn.Size = new System.Drawing.Size(96, 31);
            this.SaveTownbtn.TabIndex = 8;
            this.SaveTownbtn.Text = "Сохранить";
            this.SaveTownbtn.UseVisualStyleBackColor = true;
            this.SaveTownbtn.Click += new System.EventHandler(this.SaveTownbtn_Click);
            // 
            // DelTownbtn
            // 
            this.DelTownbtn.Location = new System.Drawing.Point(826, 92);
            this.DelTownbtn.Name = "DelTownbtn";
            this.DelTownbtn.Size = new System.Drawing.Size(87, 31);
            this.DelTownbtn.TabIndex = 7;
            this.DelTownbtn.Text = "Удалить";
            this.DelTownbtn.UseVisualStyleBackColor = true;
            this.DelTownbtn.Click += new System.EventHandler(this.DelTownbtn_Click);
            // 
            // EditTownbtn
            // 
            this.EditTownbtn.Location = new System.Drawing.Point(713, 92);
            this.EditTownbtn.Name = "EditTownbtn";
            this.EditTownbtn.Size = new System.Drawing.Size(107, 31);
            this.EditTownbtn.TabIndex = 6;
            this.EditTownbtn.Text = "Изменить";
            this.EditTownbtn.UseVisualStyleBackColor = true;
            this.EditTownbtn.Click += new System.EventHandler(this.EditTownbtn_Click);
            // 
            // AddTownbtn
            // 
            this.AddTownbtn.Location = new System.Drawing.Point(611, 92);
            this.AddTownbtn.Name = "AddTownbtn";
            this.AddTownbtn.Size = new System.Drawing.Size(96, 31);
            this.AddTownbtn.TabIndex = 5;
            this.AddTownbtn.Text = "Добавить";
            this.AddTownbtn.UseVisualStyleBackColor = true;
            this.AddTownbtn.Click += new System.EventHandler(this.AddTownbtn_Click);
            // 
            // textBoxPhoneCode
            // 
            this.textBoxPhoneCode.Location = new System.Drawing.Point(826, 54);
            this.textBoxPhoneCode.Name = "textBoxPhoneCode";
            this.textBoxPhoneCode.Size = new System.Drawing.Size(189, 22);
            this.textBoxPhoneCode.TabIndex = 4;
            // 
            // textBoxNameTown
            // 
            this.textBoxNameTown.Location = new System.Drawing.Point(611, 54);
            this.textBoxNameTown.Name = "textBoxNameTown";
            this.textBoxNameTown.Size = new System.Drawing.Size(209, 22);
            this.textBoxNameTown.TabIndex = 3;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(823, 34);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(170, 17);
            this.label9.TabIndex = 2;
            this.label9.Text = "Телефонный код города";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(608, 34);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(121, 17);
            this.label8.TabIndex = 1;
            this.label8.Text = "Название города";
            // 
            // dataGridViewTowns
            // 
            this.dataGridViewTowns.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTowns.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewTowns.Name = "dataGridViewTowns";
            this.dataGridViewTowns.ReadOnly = true;
            this.dataGridViewTowns.RowHeadersWidth = 51;
            this.dataGridViewTowns.RowTemplate.Height = 24;
            this.dataGridViewTowns.Size = new System.Drawing.Size(569, 531);
            this.dataGridViewTowns.TabIndex = 0;
            this.dataGridViewTowns.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTowns_CellClick);
            // 
            // tabPageNameVacancy
            // 
            this.tabPageNameVacancy.Controls.Add(this.dataGridViewVacancy);
            this.tabPageNameVacancy.Controls.Add(this.SaveVacancybtn);
            this.tabPageNameVacancy.Controls.Add(this.DelVacancybtn);
            this.tabPageNameVacancy.Controls.Add(this.EditVacancybtn);
            this.tabPageNameVacancy.Controls.Add(this.AddVacancybtn);
            this.tabPageNameVacancy.Controls.Add(this.textBoxNameVacancy);
            this.tabPageNameVacancy.Controls.Add(this.label11);
            this.tabPageNameVacancy.Location = new System.Drawing.Point(4, 25);
            this.tabPageNameVacancy.Name = "tabPageNameVacancy";
            this.tabPageNameVacancy.Size = new System.Drawing.Size(1075, 543);
            this.tabPageNameVacancy.TabIndex = 3;
            this.tabPageNameVacancy.Text = "Справочник вакансий";
            this.tabPageNameVacancy.UseVisualStyleBackColor = true;
            // 
            // dataGridViewVacancy
            // 
            this.dataGridViewVacancy.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVacancy.Location = new System.Drawing.Point(3, 3);
            this.dataGridViewVacancy.Name = "dataGridViewVacancy";
            this.dataGridViewVacancy.ReadOnly = true;
            this.dataGridViewVacancy.RowHeadersWidth = 51;
            this.dataGridViewVacancy.RowTemplate.Height = 24;
            this.dataGridViewVacancy.Size = new System.Drawing.Size(566, 531);
            this.dataGridViewVacancy.TabIndex = 17;
            this.dataGridViewVacancy.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewVacancy_CellClick);
            // 
            // SaveVacancybtn
            // 
            this.SaveVacancybtn.Location = new System.Drawing.Point(944, 84);
            this.SaveVacancybtn.Name = "SaveVacancybtn";
            this.SaveVacancybtn.Size = new System.Drawing.Size(101, 31);
            this.SaveVacancybtn.TabIndex = 16;
            this.SaveVacancybtn.Text = "Сохранить";
            this.SaveVacancybtn.UseVisualStyleBackColor = true;
            this.SaveVacancybtn.Click += new System.EventHandler(this.SaveVacancybtn_Click);
            // 
            // DelVacancybtn
            // 
            this.DelVacancybtn.Location = new System.Drawing.Point(850, 84);
            this.DelVacancybtn.Name = "DelVacancybtn";
            this.DelVacancybtn.Size = new System.Drawing.Size(88, 31);
            this.DelVacancybtn.TabIndex = 15;
            this.DelVacancybtn.Text = "Удалить";
            this.DelVacancybtn.UseVisualStyleBackColor = true;
            this.DelVacancybtn.Click += new System.EventHandler(this.DelVacancybtn_Click);
            // 
            // EditVacancybtn
            // 
            this.EditVacancybtn.Location = new System.Drawing.Point(737, 84);
            this.EditVacancybtn.Name = "EditVacancybtn";
            this.EditVacancybtn.Size = new System.Drawing.Size(107, 31);
            this.EditVacancybtn.TabIndex = 14;
            this.EditVacancybtn.Text = "Изменить";
            this.EditVacancybtn.UseVisualStyleBackColor = true;
            this.EditVacancybtn.Click += new System.EventHandler(this.EditVacancybtn_Click);
            // 
            // AddVacancybtn
            // 
            this.AddVacancybtn.Location = new System.Drawing.Point(635, 84);
            this.AddVacancybtn.Name = "AddVacancybtn";
            this.AddVacancybtn.Size = new System.Drawing.Size(96, 31);
            this.AddVacancybtn.TabIndex = 13;
            this.AddVacancybtn.Text = "Добавить";
            this.AddVacancybtn.UseVisualStyleBackColor = true;
            this.AddVacancybtn.Click += new System.EventHandler(this.AddVacancybtn_Click);
            // 
            // textBoxNameVacancy
            // 
            this.textBoxNameVacancy.Location = new System.Drawing.Point(635, 46);
            this.textBoxNameVacancy.Name = "textBoxNameVacancy";
            this.textBoxNameVacancy.Size = new System.Drawing.Size(410, 22);
            this.textBoxNameVacancy.TabIndex = 11;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(632, 26);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(137, 17);
            this.label11.TabIndex = 9;
            this.label11.Text = "Название вакансии";
            // 
            // Closebtn
            // 
            this.Closebtn.Location = new System.Drawing.Point(1007, 12);
            this.Closebtn.Name = "Closebtn";
            this.Closebtn.Size = new System.Drawing.Size(88, 31);
            this.Closebtn.TabIndex = 12;
            this.Closebtn.Text = "Закрыть";
            this.Closebtn.UseVisualStyleBackColor = true;
            this.Closebtn.Click += new System.EventHandler(this.Closebtn_Click);
            // 
            // EmploersForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1107, 612);
            this.Controls.Add(this.Closebtn);
            this.Controls.Add(this.tabControlEmployers);
            this.Name = "EmploersForm";
            this.Text = "Добавление вакансии и работодателя";
            this.Load += new System.EventHandler(this.EmploersForm_Load);
            this.tabControlEmployers.ResumeLayout(false);
            this.tabPageEmployers.ResumeLayout(false);
            this.tabPageEmployers.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEmployers)).EndInit();
            this.tabPageVacancy.ResumeLayout(false);
            this.tabPageVacancy.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListVacancy)).EndInit();
            this.tabPageTowns.ResumeLayout(false);
            this.tabPageTowns.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTowns)).EndInit();
            this.tabPageNameVacancy.ResumeLayout(false);
            this.tabPageNameVacancy.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVacancy)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControlEmployers;
        private System.Windows.Forms.TabPage tabPageEmployers;
        private System.Windows.Forms.TabPage tabPageVacancy;
        private System.Windows.Forms.DataGridView dataGridViewEmployers;
        private System.Windows.Forms.ComboBox Townscombo;
        private System.Windows.Forms.TextBox textBoxNameEmployer;
        private System.Windows.Forms.TextBox textBoxDirector;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxEndTime;
        private System.Windows.Forms.MaskedTextBox maskedTextBoxBeginTime;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Closebtn;
        private System.Windows.Forms.DataGridView dataGridViewListVacancy;
        private System.Windows.Forms.TabPage tabPageTowns;
        private System.Windows.Forms.TextBox textBoxPhoneCode;
        private System.Windows.Forms.TextBox textBoxNameTown;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridViewTowns;
        private System.Windows.Forms.TabPage tabPageNameVacancy;
        private System.Windows.Forms.Button SaveTownbtn;
        private System.Windows.Forms.Button DelTownbtn;
        private System.Windows.Forms.Button EditTownbtn;
        private System.Windows.Forms.Button AddTownbtn;
        private System.Windows.Forms.DataGridView dataGridViewVacancy;
        private System.Windows.Forms.Button SaveVacancybtn;
        private System.Windows.Forms.Button DelVacancybtn;
        private System.Windows.Forms.Button EditVacancybtn;
        private System.Windows.Forms.Button AddVacancybtn;
        private System.Windows.Forms.TextBox textBoxNameVacancy;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button SaveEmployerbtn;
        private System.Windows.Forms.Button DelEmployerbtn;
        private System.Windows.Forms.Button EditEmployerbtn;
        private System.Windows.Forms.Button AddEmployerbtn;
        private System.Windows.Forms.TextBox textBoxPhone;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxAdress;
        private System.Windows.Forms.Button SaveVacInListbtn;
        private System.Windows.Forms.Button DelVacInListbtn;
        private System.Windows.Forms.Button EditVacInListbtn;
        private System.Windows.Forms.Button AddVacInListbtn;
        private System.Windows.Forms.ComboBox StatuscomboBox;
        private System.Windows.Forms.TextBox SalarytextBox;
        private System.Windows.Forms.ComboBox EmployerscomboBox;
        private System.Windows.Forms.ComboBox VacancycomboBox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label12;
    }
}