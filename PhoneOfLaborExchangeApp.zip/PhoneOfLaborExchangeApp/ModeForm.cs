﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhoneOfLaborExchangeApp
{
    public partial class ModeForm : Form
    {
        public ModeForm()
        {
            InitializeComponent();
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
        }

        private void Cancelbtn_Click(object sender, EventArgs e)
        {
            Form1 main = this.Owner as Form1;
            if (main != null)
            {
                main.UserMode = -1;
            }
            Close();
        }

        private void Runbtn_Click(object sender, EventArgs e)
        {
            // Создаем и открываем соединение с MySQL
            string @strConn = "";
            using (StreamReader sr = new StreamReader("BDConnect.ini"))
            {
                while (sr.Peek() >= 0)
                {
                    strConn = @sr.ReadLine();
                }
            }
            MySqlConnection conn = new MySqlConnection(@strConn);
            conn.Open();
            // запрос

            string sql = "Select * from UserRoles where Login=@username AND Password=@password";
            // объект для выполнения SQL-запроса

            MySqlCommand command = new MySqlCommand(sql, conn);
            command.Parameters.AddWithValue("@username", LogintextBox.Text);
            command.Parameters.AddWithValue("@password", PasswordtextBox.Text);
            // выполняем запрос и получаем ответ
            MySqlDataReader dr = command.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                int uRole = Convert.ToInt32(dr.GetValue(3));
                string uId = "";
                switch (uRole)
                {
                    case 0:
                        MessageBox.Show("Вы входите в систему как администратор!");
                        break;
                    case 1:
                        MessageBox.Show("Вы входите в систему как сотрудник биржи!");
                        break;
                    case 2:
                        MessageBox.Show("Вы входите в систему как работодатель!");
                        uId = Convert.ToString(dr.GetValue(4));
                        break;
                    case 3:
                        MessageBox.Show("Вы входите в систему как соискатель!");
                        break;
                }
                conn.Close();
                Form1 main = this.Owner as Form1;
                if (main != null)
                {
                    main.UserMode = uRole;
                    main.IdE = uId;
                }
                this.Close();
            }
            else
            {
                MessageBox.Show("Неверный пароль!");
                conn.Close();
            }
        }

        private void PasswordtextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Runbtn_Click(sender, e);
            }
        }
    }
}
