﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhoneOfLaborExchangeApp
{
    public partial class UsersForm : Form
    {
        public string ID;
        public UsersForm()
        {
            InitializeComponent();
            // Создаем и открываем соединение с MySQL
            string @strConn = "";
            using (StreamReader sr = new StreamReader("BDConnect.ini"))
            {
                while (sr.Peek() >= 0)
                {
                    strConn = @sr.ReadLine();
                }
            }
            MySqlConnection conn = new MySqlConnection(@strConn);
            try
            {
                conn.Open();
                MySqlDataAdapter usDA = new MySqlDataAdapter("SELECT * FROM phoneoflaborexchange.roles", conn);
                DataTable usDATA = new DataTable();
                usDA.Fill(usDATA);
                RolescomboBox.DataSource = usDATA;
                RolescomboBox.DisplayMember = "Info";
                RolescomboBox.ValueMember = "IdR";
                RolescomboBox.SelectedIndex = -1;
                MySqlDataAdapter empDA = new MySqlDataAdapter("SELECT * FROM phoneoflaborexchange.employers", conn);
                DataTable empDATA = new DataTable();
                empDA.Fill(empDATA);
                EmployerscomboBox.DataSource = empDATA;
                EmployerscomboBox.DisplayMember = "NameEmployer";
                EmployerscomboBox.ValueMember = "IdE";
                EmployerscomboBox.SelectedIndex = -1;
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void FillUsers()
        {
            // Создаем и открываем соединение с MySQL
            string @strConn = "";
            using (StreamReader sr = new StreamReader("BDConnect.ini"))
            {
                while (sr.Peek() >= 0)
                {
                    strConn = @sr.ReadLine();
                }
            }
            MySqlConnection conn = new MySqlConnection(@strConn);
            try
            {
                conn.Open();
                MySqlDataAdapter SDA = new MySqlDataAdapter("SELECT * FROM phoneoflaborexchange.UserRolesView", conn);
                DataTable DATA = new DataTable();
                SDA.Fill(DATA);
                dataGridViewUsers.DataSource = DATA;
                dataGridViewUsers.Columns[1].HeaderText = "Логин";
                dataGridViewUsers.Columns[2].HeaderText = "Пароль";
                dataGridViewUsers.Columns[3].HeaderText = "Пользовательская роль";
                dataGridViewUsers.Columns[4].HeaderText = "Работодатель";
                dataGridViewUsers.Columns[1].Width = 90;
                dataGridViewUsers.Columns[2].Width = 90;
                dataGridViewUsers.Columns[3].Width = 110;
                dataGridViewUsers.Columns[4].Width = 180;
                dataGridViewUsers.Columns[0].Width = 0;
                conn.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void Closebtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UsersForm_Load(object sender, EventArgs e)
        {
            FillUsers();
        }

        private void AddVacancybtn_Click(object sender, EventArgs e)
        {
            string SQLStr = "";
            if (LogintextBox.Text != "" && PasswordtextBox.Text != "" && RolescomboBox.SelectedIndex > -1)
            {
                if (Convert.ToInt32(RolescomboBox.SelectedValue) == 2 && EmployerscomboBox.SelectedIndex > -1)
                {
                    SQLStr = "INSERT INTO phoneoflaborexchange.userroles (Login, Password,IdR,IdE) VALUES (";
                    SQLStr = SQLStr + "'" + LogintextBox.Text + "', ";
                    SQLStr = SQLStr + "'" + PasswordtextBox.Text + "', ";
                    SQLStr = SQLStr + "'" + Convert.ToInt32(RolescomboBox.SelectedValue).ToString() + "', ";
                    SQLStr = SQLStr + "'" + Convert.ToInt32(EmployerscomboBox.SelectedValue).ToString() + "')";
                }
                else
                {
                    SQLStr = "INSERT INTO phoneoflaborexchange.userroles (Login, Password,IdR) VALUES (";
                    SQLStr = SQLStr + "'" + LogintextBox.Text + "', ";
                    SQLStr = SQLStr + "'" + PasswordtextBox.Text + "', ";
                    SQLStr = SQLStr + "'" + Convert.ToInt32(RolescomboBox.SelectedValue).ToString() + "')";
                }
                string @strConn = "";
                using (StreamReader sr = new StreamReader("BDConnect.ini"))
                {
                    while (sr.Peek() >= 0)
                    {
                        strConn = @sr.ReadLine();
                    }
                }
                MySqlConnection conn = new MySqlConnection(@strConn);
                try
                {
                    conn.Open();
                    MySqlCommand cmnd = new MySqlCommand(SQLStr, conn);
                    cmnd.ExecuteNonQuery();
                    conn.Close();
                    FillUsers();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                MessageBox.Show("Должны быть заполнены все поля!");
            }
        }

        private void EditVacancybtn_Click(object sender, EventArgs e)
        {
            int n;
            // проверка, есть ли вообще записи в таблице
            n = dataGridViewUsers.Rows.Count;
            if (n == 1) return;
            if (dataGridViewUsers.CurrentRow.Index >= 0)
            {
                LogintextBox.Text = dataGridViewUsers.Rows[dataGridViewUsers.CurrentRow.Index].Cells[1].Value.ToString();
                PasswordtextBox.Text = dataGridViewUsers.Rows[dataGridViewUsers.CurrentRow.Index].Cells[2].Value.ToString();
                RolescomboBox.Text = dataGridViewUsers.Rows[dataGridViewUsers.CurrentRow.Index].Cells[3].Value.ToString();
                if (dataGridViewUsers.Rows[dataGridViewUsers.CurrentRow.Index].Cells[4].Value != null)
                {
                    EmployerscomboBox.Text = dataGridViewUsers.Rows[dataGridViewUsers.CurrentRow.Index].Cells[4].Value.ToString();
                }
            }
        }

        private void dataGridViewUsers_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int n;
            // проверка, есть ли вообще записи в таблице
            n = dataGridViewUsers.Rows.Count;
            if (n == 1) return;
            if (dataGridViewUsers.CurrentRow.Index >= 0)
            {
                ID = dataGridViewUsers.Rows[dataGridViewUsers.CurrentRow.Index].Cells[0].Value.ToString();
            }
        }

        private void SaveVacancybtn_Click(object sender, EventArgs e)
        {
            MessageBox.Show(LogintextBox.Text.Trim() + ", " + PasswordtextBox.Text.Trim() + ", " + RolescomboBox.SelectedIndex.ToString() + ", " + EmployerscomboBox.SelectedIndex.ToString());
            string SqlText = "UPDATE userroles SET ";
            if (LogintextBox.Text.Trim() != "" && PasswordtextBox.Text.Trim() != "" && RolescomboBox.SelectedIndex > -1 && Convert.ToInt32(RolescomboBox.SelectedValue) != 2)
            {
                MessageBox.Show("Зашли в первую ветвь");
                SqlText += " Login = '" + LogintextBox.Text.Trim() + "'";
                SqlText += ", Password = '" + PasswordtextBox.Text.Trim() + "'";
                SqlText += ", IdR = '" + Convert.ToString(Convert.ToInt32(RolescomboBox.SelectedValue)) + "'";
                SqlText += " WHERE userroles.IdU = '" + ID + "'";
            }
            else
            {
                MessageBox.Show("Зашли во вторую ветвь");
                if (LogintextBox.Text.Trim() != "" && PasswordtextBox.Text.Trim() != "" && RolescomboBox.SelectedIndex > -1 && Convert.ToInt32(RolescomboBox.SelectedValue) == 2 && EmployerscomboBox.SelectedIndex > -1)
                {
                    MessageBox.Show("Зашли в третью ветвь");
                    SqlText += " Login = '" + LogintextBox.Text.Trim() + "'";
                    SqlText += ", Password = '" + PasswordtextBox.Text.Trim() + "'";
                    SqlText += ", IdR = '" + Convert.ToString(Convert.ToInt32(RolescomboBox.SelectedValue)) + "'";
                    SqlText += ", IdE = '" + Convert.ToString(Convert.ToInt32(EmployerscomboBox.SelectedValue)) + "'";
                    SqlText += " WHERE userroles.IdU = '" + ID + "'";
                }
                else
                {
                    MessageBox.Show("Нельзя сохранить незаполненную строку!");
                    return;
                }
            }
                string @strConn = "";
                    using (StreamReader sr = new StreamReader("BDConnect.ini"))
                    {
                        while (sr.Peek() >= 0)
                        {
                            strConn = @sr.ReadLine();
                        }
                    }
                    MySqlConnection conn = new MySqlConnection(@strConn);
                    try
                    {
                        conn.Open();
                        MessageBox.Show(SqlText);
                        MySqlCommand cmnd = new MySqlCommand(SqlText, conn);
                        cmnd.ExecuteNonQuery();
                        conn.Close();
                        FillUsers();
                        LogintextBox.Text = "";
                        PasswordtextBox.Text = "";
                        RolescomboBox.SelectedIndex = -1;
                        EmployerscomboBox.SelectedIndex = -1;
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
        }

        private void DelVacancybtn_Click(object sender, EventArgs e)
        {
            int n;
            string SqlText = "DELETE FROM userroles WHERE userroles.IdU = ";
            // проверка, есть ли вообще записи в таблице
            n = dataGridViewUsers.Rows.Count;
            if (n == 1) return;
            if (dataGridViewUsers.CurrentRow.Index >= 0)
                if (MessageBox.Show("Вы действительно хотите удалить запись? Это действие нельзя будет отменить", "Удаление записи", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    string @strConn = "";
                    using (StreamReader sr = new StreamReader("BDConnect.ini"))
                    {
                        while (sr.Peek() >= 0)
                        {
                            strConn = @sr.ReadLine();
                        }
                    }
                    MySqlConnection conn = new MySqlConnection(@strConn);
                    try
                    {
                        SqlText += ID;
                        conn.Open();
                        MySqlCommand cmnd = new MySqlCommand(SqlText, conn);
                        cmnd.ExecuteNonQuery();
                        conn.Close();
                        FillUsers();
                    }
                    catch (Exception ex)
                    {

                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
        }
    }
}
