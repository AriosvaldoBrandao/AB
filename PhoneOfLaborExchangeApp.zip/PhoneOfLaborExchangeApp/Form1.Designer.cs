﻿
namespace PhoneOfLaborExchangeApp
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Cancelbtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.VacancytextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.Townscombo = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ActiveVacancylbl = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.BeginSalarytextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.EndSalarytextBox = new System.Windows.Forms.TextBox();
            this.ActiveVacancyRunbtn = new System.Windows.Forms.Button();
            this.EmployerAddFormShowbtn = new System.Windows.Forms.Button();
            this.VacancyAddFormShowbtn = new System.Windows.Forms.Button();
            this.AddTownFormShowbtn = new System.Windows.Forms.Button();
            this.AddUserFormShowbtn = new System.Windows.Forms.Button();
            this.AddVacancyNameFormShowbtn = new System.Windows.Forms.Button();
            this.VacancyOfEmpShowbtn = new System.Windows.Forms.Button();
            this.FindVacancybtn = new System.Windows.Forms.Button();
            this.Clearbtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // Cancelbtn
            // 
            this.Cancelbtn.Location = new System.Drawing.Point(1271, 2);
            this.Cancelbtn.Name = "Cancelbtn";
            this.Cancelbtn.Size = new System.Drawing.Size(75, 33);
            this.Cancelbtn.TabIndex = 5;
            this.Cancelbtn.Text = "Выход";
            this.Cancelbtn.UseVisualStyleBackColor = true;
            this.Cancelbtn.Click += new System.EventHandler(this.Cancelbtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 38);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1156, 430);
            this.dataGridView1.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Список вакансий";
            // 
            // VacancytextBox
            // 
            this.VacancytextBox.Location = new System.Drawing.Point(21, 516);
            this.VacancytextBox.Name = "VacancytextBox";
            this.VacancytextBox.Size = new System.Drawing.Size(356, 22);
            this.VacancytextBox.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 496);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Вакансия";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(380, 495);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "Город";
            // 
            // Townscombo
            // 
            this.Townscombo.FormattingEnabled = true;
            this.Townscombo.Location = new System.Drawing.Point(383, 516);
            this.Townscombo.Name = "Townscombo";
            this.Townscombo.Size = new System.Drawing.Size(283, 24);
            this.Townscombo.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(698, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 17);
            this.label4.TabIndex = 12;
            this.label4.Text = "Активных вакансий: ";
            // 
            // ActiveVacancylbl
            // 
            this.ActiveVacancylbl.AutoSize = true;
            this.ActiveVacancylbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ActiveVacancylbl.Location = new System.Drawing.Point(847, 18);
            this.ActiveVacancylbl.Name = "ActiveVacancylbl";
            this.ActiveVacancylbl.Size = new System.Drawing.Size(17, 17);
            this.ActiveVacancylbl.TabIndex = 13;
            this.ActiveVacancylbl.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(669, 496);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 17);
            this.label5.TabIndex = 14;
            this.label5.Text = "Оклад от";
            // 
            // BeginSalarytextBox
            // 
            this.BeginSalarytextBox.Location = new System.Drawing.Point(672, 516);
            this.BeginSalarytextBox.Name = "BeginSalarytextBox";
            this.BeginSalarytextBox.Size = new System.Drawing.Size(113, 22);
            this.BeginSalarytextBox.TabIndex = 15;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(792, 495);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(24, 17);
            this.label6.TabIndex = 16;
            this.label6.Text = "до";
            // 
            // EndSalarytextBox
            // 
            this.EndSalarytextBox.Location = new System.Drawing.Point(791, 516);
            this.EndSalarytextBox.Name = "EndSalarytextBox";
            this.EndSalarytextBox.Size = new System.Drawing.Size(113, 22);
            this.EndSalarytextBox.TabIndex = 17;
            // 
            // ActiveVacancyRunbtn
            // 
            this.ActiveVacancyRunbtn.Location = new System.Drawing.Point(923, 12);
            this.ActiveVacancyRunbtn.Name = "ActiveVacancyRunbtn";
            this.ActiveVacancyRunbtn.Size = new System.Drawing.Size(245, 23);
            this.ActiveVacancyRunbtn.TabIndex = 18;
            this.ActiveVacancyRunbtn.Text = "Показать свободные вакансии";
            this.ActiveVacancyRunbtn.UseVisualStyleBackColor = true;
            this.ActiveVacancyRunbtn.Click += new System.EventHandler(this.ActiveVacancyRunbtn_Click);
            // 
            // EmployerAddFormShowbtn
            // 
            this.EmployerAddFormShowbtn.Location = new System.Drawing.Point(1212, 60);
            this.EmployerAddFormShowbtn.Name = "EmployerAddFormShowbtn";
            this.EmployerAddFormShowbtn.Size = new System.Drawing.Size(124, 44);
            this.EmployerAddFormShowbtn.TabIndex = 19;
            this.EmployerAddFormShowbtn.Text = "Добавить работодателя";
            this.EmployerAddFormShowbtn.UseVisualStyleBackColor = true;
            this.EmployerAddFormShowbtn.Click += new System.EventHandler(this.EmployerAddFormShowbtn_Click);
            // 
            // VacancyAddFormShowbtn
            // 
            this.VacancyAddFormShowbtn.Location = new System.Drawing.Point(1212, 110);
            this.VacancyAddFormShowbtn.Name = "VacancyAddFormShowbtn";
            this.VacancyAddFormShowbtn.Size = new System.Drawing.Size(124, 44);
            this.VacancyAddFormShowbtn.TabIndex = 20;
            this.VacancyAddFormShowbtn.Text = "Добавить вакансию";
            this.VacancyAddFormShowbtn.UseVisualStyleBackColor = true;
            this.VacancyAddFormShowbtn.Click += new System.EventHandler(this.VacancyAddFormShowbtn_Click);
            // 
            // AddTownFormShowbtn
            // 
            this.AddTownFormShowbtn.Location = new System.Drawing.Point(1212, 160);
            this.AddTownFormShowbtn.Name = "AddTownFormShowbtn";
            this.AddTownFormShowbtn.Size = new System.Drawing.Size(124, 44);
            this.AddTownFormShowbtn.TabIndex = 21;
            this.AddTownFormShowbtn.Text = "Добавить город";
            this.AddTownFormShowbtn.UseVisualStyleBackColor = true;
            this.AddTownFormShowbtn.Click += new System.EventHandler(this.AddTownFormShowbtn_Click);
            // 
            // AddUserFormShowbtn
            // 
            this.AddUserFormShowbtn.Location = new System.Drawing.Point(1212, 281);
            this.AddUserFormShowbtn.Name = "AddUserFormShowbtn";
            this.AddUserFormShowbtn.Size = new System.Drawing.Size(124, 44);
            this.AddUserFormShowbtn.TabIndex = 22;
            this.AddUserFormShowbtn.Text = "Добавить пользователя";
            this.AddUserFormShowbtn.UseVisualStyleBackColor = true;
            this.AddUserFormShowbtn.Click += new System.EventHandler(this.AddUserFormShowbtn_Click);
            // 
            // AddVacancyNameFormShowbtn
            // 
            this.AddVacancyNameFormShowbtn.Location = new System.Drawing.Point(1212, 210);
            this.AddVacancyNameFormShowbtn.Name = "AddVacancyNameFormShowbtn";
            this.AddVacancyNameFormShowbtn.Size = new System.Drawing.Size(124, 44);
            this.AddVacancyNameFormShowbtn.TabIndex = 23;
            this.AddVacancyNameFormShowbtn.Text = "Добавить должность";
            this.AddVacancyNameFormShowbtn.UseVisualStyleBackColor = true;
            this.AddVacancyNameFormShowbtn.Click += new System.EventHandler(this.AddVacancyNameFormShowbtn_Click);
            // 
            // VacancyOfEmpShowbtn
            // 
            this.VacancyOfEmpShowbtn.Location = new System.Drawing.Point(923, 474);
            this.VacancyOfEmpShowbtn.Name = "VacancyOfEmpShowbtn";
            this.VacancyOfEmpShowbtn.Size = new System.Drawing.Size(245, 23);
            this.VacancyOfEmpShowbtn.TabIndex = 24;
            this.VacancyOfEmpShowbtn.Text = "Показать вакансии организации";
            this.VacancyOfEmpShowbtn.UseVisualStyleBackColor = true;
            this.VacancyOfEmpShowbtn.Click += new System.EventHandler(this.VacancyOfEmpShowbtn_Click);
            // 
            // FindVacancybtn
            // 
            this.FindVacancybtn.Location = new System.Drawing.Point(923, 515);
            this.FindVacancybtn.Name = "FindVacancybtn";
            this.FindVacancybtn.Size = new System.Drawing.Size(245, 23);
            this.FindVacancybtn.TabIndex = 25;
            this.FindVacancybtn.Text = "Найти вакансии";
            this.FindVacancybtn.UseVisualStyleBackColor = true;
            this.FindVacancybtn.Click += new System.EventHandler(this.FindVacancybtn_Click);
            // 
            // Clearbtn
            // 
            this.Clearbtn.Location = new System.Drawing.Point(923, 544);
            this.Clearbtn.Name = "Clearbtn";
            this.Clearbtn.Size = new System.Drawing.Size(245, 23);
            this.Clearbtn.TabIndex = 26;
            this.Clearbtn.Text = "Очистить поиск";
            this.Clearbtn.UseVisualStyleBackColor = true;
            this.Clearbtn.Click += new System.EventHandler(this.Clearbtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1348, 598);
            this.Controls.Add(this.Clearbtn);
            this.Controls.Add(this.FindVacancybtn);
            this.Controls.Add(this.VacancyOfEmpShowbtn);
            this.Controls.Add(this.AddVacancyNameFormShowbtn);
            this.Controls.Add(this.AddUserFormShowbtn);
            this.Controls.Add(this.AddTownFormShowbtn);
            this.Controls.Add(this.VacancyAddFormShowbtn);
            this.Controls.Add(this.EmployerAddFormShowbtn);
            this.Controls.Add(this.ActiveVacancyRunbtn);
            this.Controls.Add(this.EndSalarytextBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.BeginSalarytextBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ActiveVacancylbl);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.Townscombo);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.VacancytextBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Cancelbtn);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Телефонный справочник биржи труда";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Cancelbtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox VacancytextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox Townscombo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label ActiveVacancylbl;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox BeginSalarytextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox EndSalarytextBox;
        private System.Windows.Forms.Button ActiveVacancyRunbtn;
        private System.Windows.Forms.Button EmployerAddFormShowbtn;
        private System.Windows.Forms.Button VacancyAddFormShowbtn;
        private System.Windows.Forms.Button AddTownFormShowbtn;
        private System.Windows.Forms.Button AddUserFormShowbtn;
        private System.Windows.Forms.Button AddVacancyNameFormShowbtn;
        private System.Windows.Forms.Button VacancyOfEmpShowbtn;
        private System.Windows.Forms.Button FindVacancybtn;
        private System.Windows.Forms.Button Clearbtn;
    }
}

